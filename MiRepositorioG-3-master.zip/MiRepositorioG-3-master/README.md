# MiRepositorioG-3
Aquí se almacenará todo el código que usaremos para el examen
el usuario jose01 es superusuario, clave j1234567
         * el usuario pedro02 es administrador, clave p1234567
         * el usuario luis03 es cajero, clave l1234567
