﻿namespace sistemaCompra
{
    partial class AgregarCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtDireccion = new TextBox();
            txtCorreo = new TextBox();
            txtTelefono = new TextBox();
            txtNombreCliente = new TextBox();
            txtCodigoCliente = new TextBox();
            txtApellido = new TextBox();
            txtIdentificacion = new TextBox();
            pboxAceptar = new PictureBox();
            pboxAgregarCl = new PictureBox();
            pboxCodigoCliente = new PictureBox();
            pboxNombreCliente = new PictureBox();
            pboxApellido = new PictureBox();
            pboxIdentificacion = new PictureBox();
            pboxTelefono = new PictureBox();
            pboxCorreo = new PictureBox();
            pboxDireccion = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pboxAceptar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxAgregarCl).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxCodigoCliente).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxNombreCliente).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxApellido).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxIdentificacion).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxTelefono).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxCorreo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxDireccion).BeginInit();
            SuspendLayout();
            // 
            // txtDireccion
            // 
            txtDireccion.Location = new Point(354, 301);
            txtDireccion.Margin = new Padding(3, 4, 3, 4);
            txtDireccion.Multiline = true;
            txtDireccion.Name = "txtDireccion";
            txtDireccion.Size = new Size(256, 94);
            txtDireccion.TabIndex = 45;
            // 
            // txtCorreo
            // 
            txtCorreo.Location = new Point(142, 380);
            txtCorreo.Margin = new Padding(3, 4, 3, 4);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(151, 27);
            txtCorreo.TabIndex = 41;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(130, 288);
            txtTelefono.Margin = new Padding(3, 4, 3, 4);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(164, 27);
            txtTelefono.TabIndex = 39;
            // 
            // txtNombreCliente
            // 
            txtNombreCliente.Location = new Point(104, 181);
            txtNombreCliente.Margin = new Padding(3, 4, 3, 4);
            txtNombreCliente.Name = "txtNombreCliente";
            txtNombreCliente.Size = new Size(189, 27);
            txtNombreCliente.TabIndex = 37;
            // 
            // txtCodigoCliente
            // 
            txtCodigoCliente.Location = new Point(104, 85);
            txtCodigoCliente.Margin = new Padding(3, 4, 3, 4);
            txtCodigoCliente.Name = "txtCodigoCliente";
            txtCodigoCliente.Size = new Size(173, 27);
            txtCodigoCliente.TabIndex = 35;
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(428, 172);
            txtApellido.Margin = new Padding(3, 4, 3, 4);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(182, 27);
            txtApellido.TabIndex = 49;
            // 
            // txtIdentificacion
            // 
            txtIdentificacion.Location = new Point(744, 195);
            txtIdentificacion.Margin = new Padding(3, 4, 3, 4);
            txtIdentificacion.Name = "txtIdentificacion";
            txtIdentificacion.Size = new Size(146, 27);
            txtIdentificacion.TabIndex = 51;
            // 
            // pboxAceptar
            // 
            pboxAceptar.Image = Properties.Resources.BotonAceptar;
            pboxAceptar.Location = new Point(744, 329);
            pboxAceptar.Margin = new Padding(3, 4, 3, 4);
            pboxAceptar.Name = "pboxAceptar";
            pboxAceptar.Size = new Size(122, 52);
            pboxAceptar.SizeMode = PictureBoxSizeMode.Zoom;
            pboxAceptar.TabIndex = 52;
            pboxAceptar.TabStop = false;
            // 
            // pboxAgregarCl
            // 
            pboxAgregarCl.Image = Properties.Resources.ClienteNuevo1;
            pboxAgregarCl.Location = new Point(257, 16);
            pboxAgregarCl.Margin = new Padding(3, 4, 3, 4);
            pboxAgregarCl.Name = "pboxAgregarCl";
            pboxAgregarCl.Size = new Size(336, 61);
            pboxAgregarCl.SizeMode = PictureBoxSizeMode.Zoom;
            pboxAgregarCl.TabIndex = 54;
            pboxAgregarCl.TabStop = false;
            // 
            // pboxCodigoCliente
            // 
            pboxCodigoCliente.Image = Properties.Resources.ClienteNuevo21;
            pboxCodigoCliente.Location = new Point(25, 85);
            pboxCodigoCliente.Margin = new Padding(3, 4, 3, 4);
            pboxCodigoCliente.Name = "pboxCodigoCliente";
            pboxCodigoCliente.Size = new Size(253, 60);
            pboxCodigoCliente.SizeMode = PictureBoxSizeMode.Zoom;
            pboxCodigoCliente.TabIndex = 55;
            pboxCodigoCliente.TabStop = false;
            // 
            // pboxNombreCliente
            // 
            pboxNombreCliente.Image = Properties.Resources.ClienteNuevo31;
            pboxNombreCliente.Location = new Point(25, 181);
            pboxNombreCliente.Margin = new Padding(3, 4, 3, 4);
            pboxNombreCliente.Name = "pboxNombreCliente";
            pboxNombreCliente.Size = new Size(269, 60);
            pboxNombreCliente.SizeMode = PictureBoxSizeMode.Zoom;
            pboxNombreCliente.TabIndex = 56;
            pboxNombreCliente.TabStop = false;
            // 
            // pboxApellido
            // 
            pboxApellido.Image = Properties.Resources.ClienteNuevo6;
            pboxApellido.Location = new Point(333, 172);
            pboxApellido.Margin = new Padding(3, 4, 3, 4);
            pboxApellido.Name = "pboxApellido";
            pboxApellido.Size = new Size(277, 47);
            pboxApellido.SizeMode = PictureBoxSizeMode.Zoom;
            pboxApellido.TabIndex = 57;
            pboxApellido.TabStop = false;
            pboxApellido.Click += pboxApellido_Click;
            // 
            // pboxIdentificacion
            // 
            pboxIdentificacion.Image = Properties.Resources.ClienteNuevo7;
            pboxIdentificacion.Location = new Point(622, 181);
            pboxIdentificacion.Margin = new Padding(3, 4, 3, 4);
            pboxIdentificacion.Name = "pboxIdentificacion";
            pboxIdentificacion.Size = new Size(269, 60);
            pboxIdentificacion.SizeMode = PictureBoxSizeMode.Zoom;
            pboxIdentificacion.TabIndex = 58;
            pboxIdentificacion.TabStop = false;
            // 
            // pboxTelefono
            // 
            pboxTelefono.Image = Properties.Resources.ClienteNuevo4;
            pboxTelefono.Location = new Point(25, 288);
            pboxTelefono.Margin = new Padding(3, 4, 3, 4);
            pboxTelefono.Name = "pboxTelefono";
            pboxTelefono.Size = new Size(269, 53);
            pboxTelefono.SizeMode = PictureBoxSizeMode.Zoom;
            pboxTelefono.TabIndex = 59;
            pboxTelefono.TabStop = false;
            // 
            // pboxCorreo
            // 
            pboxCorreo.Image = Properties.Resources.ClienteNuevo5;
            pboxCorreo.Location = new Point(25, 368);
            pboxCorreo.Margin = new Padding(3, 4, 3, 4);
            pboxCorreo.Name = "pboxCorreo";
            pboxCorreo.Size = new Size(269, 52);
            pboxCorreo.SizeMode = PictureBoxSizeMode.Zoom;
            pboxCorreo.TabIndex = 60;
            pboxCorreo.TabStop = false;
            // 
            // pboxDireccion
            // 
            pboxDireccion.Image = Properties.Resources.ClienteNuevo8;
            pboxDireccion.Location = new Point(334, 261);
            pboxDireccion.Margin = new Padding(3, 4, 3, 4);
            pboxDireccion.Name = "pboxDireccion";
            pboxDireccion.Size = new Size(302, 171);
            pboxDireccion.SizeMode = PictureBoxSizeMode.Zoom;
            pboxDireccion.TabIndex = 61;
            pboxDireccion.TabStop = false;
            // 
            // AgregarCliente
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(926, 460);
            Controls.Add(pboxAgregarCl);
            Controls.Add(pboxAceptar);
            Controls.Add(txtIdentificacion);
            Controls.Add(txtApellido);
            Controls.Add(txtDireccion);
            Controls.Add(txtCorreo);
            Controls.Add(txtTelefono);
            Controls.Add(txtNombreCliente);
            Controls.Add(txtCodigoCliente);
            Controls.Add(pboxCodigoCliente);
            Controls.Add(pboxNombreCliente);
            Controls.Add(pboxApellido);
            Controls.Add(pboxIdentificacion);
            Controls.Add(pboxTelefono);
            Controls.Add(pboxCorreo);
            Controls.Add(pboxDireccion);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 4, 3, 4);
            Name = "AgregarCliente";
            Text = "Agregar cliente";
            Load += AgregarCliente_Load;
            ((System.ComponentModel.ISupportInitialize)pboxAceptar).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxAgregarCl).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxCodigoCliente).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxNombreCliente).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxApellido).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxIdentificacion).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxTelefono).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxCorreo).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxDireccion).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtDireccion;
        private TextBox txtCorreo;
        private TextBox txtTelefono;
        private TextBox txtNombreCliente;
        private TextBox txtCodigoCliente;
        private TextBox txtApellido;
        private TextBox txtIdentificacion;
        private PictureBox pboxAceptar;
        private PictureBox pboxAgregarCl;
        private PictureBox pboxCodigoCliente;
        private PictureBox pboxNombreCliente;
        private PictureBox pboxApellido;
        private PictureBox pboxIdentificacion;
        private PictureBox pboxTelefono;
        private PictureBox pboxCorreo;
        private PictureBox pboxDireccion;
    }
}