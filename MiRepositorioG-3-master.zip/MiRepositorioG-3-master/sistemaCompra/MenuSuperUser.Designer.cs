﻿namespace sistemaCompra
{
    partial class MenuSuperUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuSuperUser));
            pboxReseteoUsuarios = new PictureBox();
            pboxCtrlUsuarios = new PictureBox();
            pboxAvatarSuperUsuario = new PictureBox();
            pboxSuperUsuario = new PictureBox();
            pboxReseteoDatos = new PictureBox();
            pboxReseteoFabrica = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pboxReseteoUsuarios).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxCtrlUsuarios).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxAvatarSuperUsuario).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxSuperUsuario).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxReseteoDatos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pboxReseteoFabrica).BeginInit();
            SuspendLayout();
            // 
            // pboxReseteoUsuarios
            // 
            pboxReseteoUsuarios.ErrorImage = (Image)resources.GetObject("pboxReseteoUsuarios.ErrorImage");
            pboxReseteoUsuarios.Image = Properties.Resources.InterfazSuperUsuario3;
            pboxReseteoUsuarios.Location = new Point(86, 264);
            pboxReseteoUsuarios.Margin = new Padding(3, 2, 3, 2);
            pboxReseteoUsuarios.Name = "pboxReseteoUsuarios";
            pboxReseteoUsuarios.Size = new Size(190, 29);
            pboxReseteoUsuarios.SizeMode = PictureBoxSizeMode.Zoom;
            pboxReseteoUsuarios.TabIndex = 14;
            pboxReseteoUsuarios.TabStop = false;
            // 
            // pboxCtrlUsuarios
            // 
            pboxCtrlUsuarios.Image = Properties.Resources.InterfazAdmin4;
            pboxCtrlUsuarios.Location = new Point(100, 220);
            pboxCtrlUsuarios.Margin = new Padding(3, 2, 3, 2);
            pboxCtrlUsuarios.Name = "pboxCtrlUsuarios";
            pboxCtrlUsuarios.Size = new Size(152, 31);
            pboxCtrlUsuarios.SizeMode = PictureBoxSizeMode.Zoom;
            pboxCtrlUsuarios.TabIndex = 19;
            pboxCtrlUsuarios.TabStop = false;
            pboxCtrlUsuarios.Click += pboxCtrlUsuarios_Click_1;
            // 
            // pboxAvatarSuperUsuario
            // 
            pboxAvatarSuperUsuario.AccessibleRole = AccessibleRole.None;
            pboxAvatarSuperUsuario.Image = Properties.Resources.InterfazSuperUsuario2;
            pboxAvatarSuperUsuario.ImeMode = ImeMode.NoControl;
            pboxAvatarSuperUsuario.Location = new Point(117, 54);
            pboxAvatarSuperUsuario.Name = "pboxAvatarSuperUsuario";
            pboxAvatarSuperUsuario.Size = new Size(121, 147);
            pboxAvatarSuperUsuario.SizeMode = PictureBoxSizeMode.Zoom;
            pboxAvatarSuperUsuario.TabIndex = 20;
            pboxAvatarSuperUsuario.TabStop = false;
            // 
            // pboxSuperUsuario
            // 
            pboxSuperUsuario.Image = Properties.Resources.InterfazSuperUsuario1;
            pboxSuperUsuario.Location = new Point(62, 12);
            pboxSuperUsuario.Name = "pboxSuperUsuario";
            pboxSuperUsuario.Size = new Size(236, 36);
            pboxSuperUsuario.SizeMode = PictureBoxSizeMode.Zoom;
            pboxSuperUsuario.TabIndex = 21;
            pboxSuperUsuario.TabStop = false;
            // 
            // pboxReseteoDatos
            // 
            pboxReseteoDatos.ErrorImage = (Image)resources.GetObject("pboxReseteoDatos.ErrorImage");
            pboxReseteoDatos.Image = Properties.Resources.InterfazSuperUsuario4;
            pboxReseteoDatos.Location = new Point(86, 306);
            pboxReseteoDatos.Margin = new Padding(3, 2, 3, 2);
            pboxReseteoDatos.Name = "pboxReseteoDatos";
            pboxReseteoDatos.Size = new Size(190, 29);
            pboxReseteoDatos.SizeMode = PictureBoxSizeMode.Zoom;
            pboxReseteoDatos.TabIndex = 22;
            pboxReseteoDatos.TabStop = false;
            // 
            // pboxReseteoFabrica
            // 
            pboxReseteoFabrica.ErrorImage = (Image)resources.GetObject("pboxReseteoFabrica.ErrorImage");
            pboxReseteoFabrica.Image = Properties.Resources.InterfazSuperUsuario5;
            pboxReseteoFabrica.Location = new Point(86, 354);
            pboxReseteoFabrica.Margin = new Padding(3, 2, 3, 2);
            pboxReseteoFabrica.Name = "pboxReseteoFabrica";
            pboxReseteoFabrica.Size = new Size(190, 29);
            pboxReseteoFabrica.SizeMode = PictureBoxSizeMode.Zoom;
            pboxReseteoFabrica.TabIndex = 23;
            pboxReseteoFabrica.TabStop = false;
            // 
            // MenuSuperUser
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Honeydew;
            ClientSize = new Size(364, 394);
            Controls.Add(pboxReseteoFabrica);
            Controls.Add(pboxReseteoDatos);
            Controls.Add(pboxSuperUsuario);
            Controls.Add(pboxAvatarSuperUsuario);
            Controls.Add(pboxCtrlUsuarios);
            Controls.Add(pboxReseteoUsuarios);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 2, 3, 2);
            Name = "MenuSuperUser";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MenuSuperUser";
            FormClosing += MenuSuperUser_FormClosing;
            Load += MenuSuperUser_Load;
            ((System.ComponentModel.ISupportInitialize)pboxReseteoUsuarios).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxCtrlUsuarios).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxAvatarSuperUsuario).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxSuperUsuario).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxReseteoDatos).EndInit();
            ((System.ComponentModel.ISupportInitialize)pboxReseteoFabrica).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private PictureBox pboxReseteoUsuarios;
        private PictureBox pboxCtrlUsuarios;
        private PictureBox pboxAvatarSuperUsuario;
        private PictureBox pboxSuperUsuario;
        private PictureBox pboxReseteoDatos;
        private PictureBox pboxReseteoFabrica;
    }
}