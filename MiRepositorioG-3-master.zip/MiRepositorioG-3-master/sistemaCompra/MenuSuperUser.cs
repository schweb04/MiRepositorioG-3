﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaCompra
{
    public partial class MenuSuperUser : Form
    {
        public MenuSuperUser()
        {
            InitializeComponent();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }

        private void MenuSuperUser_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void pboxCtrlUsuarios_Click_1(object sender, EventArgs e)
        {
            CtrlUsuario ctrlUsuario = new CtrlUsuario();
            ctrlUsuario.ShowDialog();
        }

        private void MenuSuperUser_Load(object sender, EventArgs e)
        {

        }
    }
}
