﻿namespace sistemaCompra
{
    partial class Ventas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            label5 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            label1 = new Label();
            pictureBox5 = new PictureBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox9 = new PictureBox();
            pictureBox10 = new PictureBox();
            dataGridView1 = new DataGridView();
            Columna3 = new DataGridViewTextBoxColumn();
            Column1 = new DataGridViewTextBoxColumn();
            Fila1 = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 102);
            label5.Name = "label5";
            label5.Size = new Size(44, 15);
            label5.TabIndex = 8;
            label5.Text = "Cliente";
            label5.Click += label5_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.InterfazVentas2;
            pictureBox1.Location = new Point(351, 469);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(237, 60);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 23;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.BotonRetroceder;
            pictureBox2.Location = new Point(12, 468);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(100, 50);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 24;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.ControlDato1;
            pictureBox3.Location = new Point(45, 129);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(182, 29);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 25;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.ControlDato1;
            pictureBox4.Location = new Point(45, 231);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(182, 29);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 26;
            pictureBox4.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 215);
            label1.Name = "label1";
            label1.Size = new Size(56, 15);
            label1.TabIndex = 27;
            label1.Text = "Producto";
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.ControlDato1;
            pictureBox5.Location = new Point(45, 328);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(182, 29);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 28;
            pictureBox5.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 310);
            label2.Name = "label2";
            label2.Size = new Size(46, 15);
            label2.TabIndex = 29;
            label2.Text = "Factura";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(10, 360);
            label3.Name = "label3";
            label3.Size = new Size(27, 15);
            label3.TabIndex = 30;
            label3.Text = "IVA:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(10, 375);
            label4.Name = "label4";
            label4.Size = new Size(101, 15);
            label4.TabIndex = 31;
            label4.Text = "Precio en Dolares:";
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.InterfazVentas1;
            pictureBox6.Location = new Point(397, 8);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(129, 42);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 32;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.VentasEditar;
            pictureBox7.Location = new Point(247, 132);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(29, 26);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 33;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.VentasEditar;
            pictureBox8.Location = new Point(247, 234);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(29, 26);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 34;
            pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.VentasEditar;
            pictureBox9.Location = new Point(247, 331);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(29, 26);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 35;
            pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.InterfazVentas3;
            pictureBox10.Location = new Point(535, 60);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(356, 392);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 36;
            pictureBox10.TabStop = false;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(11, 87, 96);
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Fila1, Column1, Columna3 });
            dataGridView1.Location = new Point(535, 102);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 6;
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.ScrollBars = ScrollBars.Vertical;
            dataGridView1.Size = new Size(356, 350);
            dataGridView1.TabIndex = 37;
           
            // 
            // Columna3
            // 
            dataGridViewCellStyle3.BackColor = Color.FromArgb(11, 87, 96);
            dataGridViewCellStyle3.Font = new Font("OCR A Extended", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(11, 87, 96);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(11, 87, 96);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(11, 87, 96);
            Columna3.DefaultCellStyle = dataGridViewCellStyle3;
            Columna3.HeaderText = "Fila3";
            Columna3.Name = "Columna3";
            Columna3.Width = 116;
            // 
            // Column1
            // 
            dataGridViewCellStyle2.BackColor = Color.FromArgb(11, 87, 96);
            dataGridViewCellStyle2.Font = new Font("OCR A Extended", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.FromArgb(11, 87, 96);
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(11, 87, 96);
            dataGridViewCellStyle2.SelectionForeColor = Color.FromArgb(11, 87, 96);
            Column1.DefaultCellStyle = dataGridViewCellStyle2;
            Column1.DividerWidth = 5;
            Column1.HeaderText = "Fila2";
            Column1.Name = "Column1";
            Column1.Width = 116;
            // 
            // Fila1
            // 
            Fila1.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(11, 87, 96);
            dataGridViewCellStyle1.Font = new Font("OCR A Extended", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = Color.FromArgb(11, 87, 96);
            dataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(11, 87, 96);
            dataGridViewCellStyle1.SelectionForeColor = Color.FromArgb(11, 87, 96);
            Fila1.DefaultCellStyle = dataGridViewCellStyle1;
            Fila1.DividerWidth = 5;
            Fila1.HeaderText = "Fila1";
            Fila1.Name = "Fila1";
            Fila1.Width = 116;
            // 
            // Ventas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(938, 530);
            Controls.Add(dataGridView1);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox5);
            Controls.Add(label1);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label5);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Ventas";
            Text = "Ventas";
            Load += Ventas_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label5;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private Label label1;
        private PictureBox pictureBox5;
        private Label label2;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Fila1;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Columna3;
    }
}